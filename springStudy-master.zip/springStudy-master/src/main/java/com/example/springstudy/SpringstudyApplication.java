package com.example.springstudy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringstudyApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringstudyApplication.class, args);
    }

}
