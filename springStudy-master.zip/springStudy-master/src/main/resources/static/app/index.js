$(document).ready(function () {
    console.log("init")
});